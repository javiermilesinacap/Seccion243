import './App.css';
import 'antd/dist/antd.min.css'
import Plantilla from './features/plantilla/Plantilla';

function App() {
  return (
    <div className="App">
      <Plantilla />
    </div>
  );
}

export default App;
