import antd from 'antd/dist/antd.min.css'
import './App.css';
import ProductoList from './features/producto/ProductoList';

function App() {
  return (
    <div>
     <ProductoList />
    </div>
  );
}

export default App;
